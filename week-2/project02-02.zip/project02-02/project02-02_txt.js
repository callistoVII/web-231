/*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: Niki Nielsen
      Date: 04/01/2024

      Filename: project02-02.js
 */

